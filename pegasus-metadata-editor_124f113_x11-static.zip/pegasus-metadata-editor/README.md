# Pegasus Metadata Editor

A simple editor for the metadata files of [Pegasus](http://pegasus-frontend.org).

![screenshot](https://snipboard.io/jvemLa.jpg)
![screenshot](https://snipboard.io/nKNWkt.jpg)

You can download it [**from here**](https://github.com/mmatyas/pegasus-metadata-editor/releases).

Also avaliable from AUR! Look for [`pegasus-metadata-editor-git`](https://aur.archlinux.org/packages/pegasus-metadata-editor-git/).
